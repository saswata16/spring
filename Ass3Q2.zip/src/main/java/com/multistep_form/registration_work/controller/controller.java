package com.multistep_form.registration_work.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class controller {
	@GetMapping("/")
	public String form(Model model) {
		Player player = new Player();
		model.addAttribute("player", player);
		return "index";
	}
	
	@PostMapping("/playerdata")
	public String submit_form(@ModelAttribute("player") Player player) {
		System.out.println(player);
		return "playerdata";
	}
}

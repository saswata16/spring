package com.multistep_form.registration_work.controller;

public class Player {
	private String name;
	private String dob;
	private String gender;
	
	private String rating;
	private String rank;
	private String fav_forward;
	private String mode;
	
	private String ph;
	private String email;
	private String hobby;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getFav_forward() {
		return fav_forward;
	}
	public void setFav_forward(String fav_forward) {
		this.fav_forward = fav_forward;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getPh() {
		return ph;
	}
	public void setPh(String ph) {
		this.ph = ph;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	@Override
	public String toString() {
		return "Player [name=" + name + ", dob=" + dob + ", gender=" + gender + ", rating=" + rating + ", rank=" + rank
				+ ", fav_forward=" + fav_forward + ", mode=" + mode + ", ph=" + ph + ", email=" + email + ", hobby="
				+ hobby + ", getName()=" + getName() + ", getDob()=" + getDob() + ", getGender()=" + getGender()
				+ ", getRating()=" + getRating() + ", getRank()=" + getRank() + ", getFav_forward()=" + getFav_forward()
				+ ", getMode()=" + getMode() + ", getPh()=" + getPh() + ", getEmail()=" + getEmail() + ", getHobby()="
				+ getHobby() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
	
	
	
}
